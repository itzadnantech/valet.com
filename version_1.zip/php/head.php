
<!---------------------------favicon--------------------------->
<link rel="shortcut icon" href="img/favicon.png"> 

<!---------- Global site tag (gtag.js) - Google Analytics -->


<!---------------------Facebook Open Graph Meta Tags----------------------------->
 

 <!-------------------- Twitter Card data --------------------------------------->


<!---------------------meta tags-----------------------------> 
<meta charset="UTF-8">
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 

<!----------------------- Css Plugins--------------------------> 
<?php include('load_css.php')?>

 





 

  