<style>
    <?php
    
    echo "\n\n /*custom css*/ \n\n";
    include 'css/custom.css';
    echo "\n\n /*select2 css*/ \n\n";
    include 'css/select2.min.css';
    
    echo "\n\n /*style css*/ \n\n";
    include 'css/style.css';
    
    
    ?>
</style>