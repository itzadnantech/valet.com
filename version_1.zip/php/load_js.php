
<script>
<?php   
		/*******J-Query Plugins******/
	include 'js/jquery.min.js';
	include 'js/select2.min.js';
	include 'js/custom.js';
    
	//include 'js/bootstrap.min.js'; 
    
    ?>
</script>
<script type="529210a053eec5510ffebb9c-text/javascript">
    <?php 
    echo "\n /* vendor.js*/ \n";
    include 'js/vendor.js';
    echo "\n";
    ?>
    
</script>
<script type="529210a053eec5510ffebb9c-text/javascript" defer="">
    <?php 
    
    echo "\n /* bundle.js*/ \n";
    include 'js/bundle.js'; 
    ?>
    
</script>
<script data-cf-settings="529210a053eec5510ffebb9c-|49" defer="">
    <?php  
    
    echo "\n /* rocket-loader*/ \n";
    include 'js/rocket-loader.min.js'; 
    ?>
</script>